import json, random, math, struct, sys
from aiogram_nav.engine import native_core
native=native_core().strict_loads
r=random.Random(81342)
values=[None,True,False,0,-1,2**200,-2**200,-0.0,1e-300,1e300,'Հայերեն😀','a\\b\n\r\t\x00']
for i in range(1000):
 value=r.choice([r.randrange(-10**60,10**60),r.uniform(-1,1)*10.0**r.randrange(-300,300),''.join(chr(r.randrange(32,127)) for _ in range(r.randrange(15)))])
 values.append(value)
raws=[json.dumps(x,ensure_ascii=bool(i%2),separators=(',',':')) for i,x in enumerate(values)]
raws += ['['+','.join(raws[i:i+8])+']' for i in range(0,len(values),8)]
for i in range(1000):
 digits=str(r.randrange(1,10))+''.join(str(r.randrange(10)) for _ in range(r.randrange(1,80)))
 raws.append(('-' if i%2 else '')+digits+'e'+str(r.randrange(-300,200)))
raws += ['-0','-0.0','1e-9999','1e9999','"\\ud800"','"\\udfff"','"\\ud800\\udfff"','{"a":1,"\\u0061":2}','{"😀":1,"\\ud83d\\ude00":2}','00','-00','01','1.','1e','1e+','[1,]','[truefalse]','{"x":1,}', '1'+'0'*4500,'['*65+'0'+']'*65]
def pack(v):
 if isinstance(v,float):return ('float',struct.pack('!d',v).hex())
 if isinstance(v,list):return ['list',*[pack(x) for x in v]]
 if isinstance(v,dict):return ['dict',*[[pack(k),pack(x)] for k,x in v.items()]]
 return (type(v).__name__,v)
results=[]
for raw in raws:
 try:results.append(['ok',pack(native(raw))])
 except Exception as x:results.append(['error',type(x).__name__])
import importlib.metadata,hashlib,pathlib,urllib.parse
from aiogram_nav_native import _aiogram_nav_native as extension
metadata={"python_executable":sys.executable,"python_version":sys.version,"extension_path":extension.__file__,"extension_sha256":hashlib.sha256(pathlib.Path(extension.__file__).read_bytes()).hexdigest(),"direct_url":json.loads(importlib.metadata.distribution("aiogram-nav-native").read_text("direct_url.json"))}
url=metadata["direct_url"]["url"]
wheel=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(url).path))
metadata["wheel_path"]=str(wheel)
metadata["wheel_sha256"]=hashlib.sha256(wheel.read_bytes()).hexdigest() if wheel.is_file() else None
json.dump({"metadata":metadata,"results":results},sys.stdout,ensure_ascii=True)
