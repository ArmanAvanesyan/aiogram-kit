import asyncio,json,sys,importlib.metadata,hashlib,pathlib,urllib.parse,zipfile
from dataclasses import replace
from aiogram_cmds import CmdsConfig,CommandDef,ProfileDef,compile_config,build_profile_batch,ProfileRequest
from aiogram_cmds.compiled_delivery import apply_compiled_profile
from aiogram_cmds.delivery import UNSET
from aiogram.types import BotCommandScopeChat,BotCommandScopeChatMember
class Bot:
 def __init__(self,response=True):self.reads=0;self.calls=[];self.response=response
 @property
 def id(self):self.reads+=1;return 123
 async def set_my_commands(self,commands,**kw):self.calls.append((commands,kw));return self.response
async def run():
 results=[]
 for engine in ['python','rust']:
  for per in [True,False]:
   cfg=CmdsConfig(languages=['en','hy','ru'],commands={'start':CommandDef(descriptions={'en':'Start','hy':'Սկիզբ😀','ru':'Старт'})},profiles={'member':ProfileDef(include=['start'])},per_language=per)
   c=replace(compile_config(cfg,config_revision='audit'),per_language=per).bind(engine)
   assert c.per_language is per
   for chat in [None,-10042]:
    scope=BotCommandScopeChat(chat_id=42) if chat is None else BotCommandScopeChatMember(chat_id=chat,user_id=42)
    for language in ['en','hy','ru']:
     for slot in [UNSET,None,'','ru']:
      b=Bot();expected=build_profile_batch(c,[ProfileRequest('member',language,123,scope.model_dump_json(),slot)],engine='python')[0]
      a=await apply_compiled_profile(b,c,user_id=42,chat_id=chat,profile='member',language=language,language_code=slot,engine=engine)
      assert a.fingerprint==a.confirmed_fingerprint==expected.fingerprint and len(b.calls)==1
      commands,kwargs=b.calls[0];assert [(x.command,x.description) for x in commands]==list(expected.commands);assert kwargs['scope'].model_dump(mode='json')==scope.model_dump(mode='json')
      assert ('language_code' not in kwargs if expected.language_code is None else kwargs['language_code']==expected.language_code)
      a=await apply_compiled_profile(b,c,user_id=42,chat_id=chat,profile='member',language=language,language_code=slot,previous_fingerprint=a.confirmed_fingerprint,engine=engine)
      assert a.status=='unchanged' and len(b.calls)==1
      results.append([engine,per,chat,language,str(slot),'pass'])
   for invalid in ['bad','F'*64,'a'*63,1]:
    b=Bot()
    try:await apply_compiled_profile(b,c,user_id=42,profile='member',previous_fingerprint=invalid,best_effort=True,engine=engine)
    except ValueError:pass
    else:raise AssertionError('bad fingerprint accepted')
    assert b.calls==[] and b.reads==0
   b=Bot(False)
   a=await apply_compiled_profile(b,c,user_id=42,profile='member',best_effort=True,engine=engine);assert a.status=='failed' and a.confirmed_fingerprint is None
   a=await apply_compiled_profile(b,c,user_id=42,profile='member',best_effort=True,engine=engine);assert a.status=='failed' and len(b.calls)==2
 return results
results=asyncio.run(run())
from _aiogram_cmds_native import _aiogram_cmds_native as ext
meta={'python':sys.executable,'native_extension':ext.__file__,'extension_sha256':hashlib.sha256(pathlib.Path(ext.__file__).read_bytes()).hexdigest()}
for dist in ['aiogram-cmds','aiogram-cmds-native']:
 x=json.loads(importlib.metadata.distribution(dist).read_text('direct_url.json'));p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(x['url']).path));meta[dist]={'direct_url':x,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
json.dump({'metadata':meta,'delivery_vectors':results,'invalid_fingerprint_vectors':16,'failed_confirmation_retry_vectors':4},sys.stdout,ensure_ascii=True)
