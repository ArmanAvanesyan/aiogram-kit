import json,sys,hashlib,importlib.metadata,pathlib,urllib.parse,zipfile
from aiogram_idle_native import _aiogram_idle_native as native
class OddInt(int):
 def __getattribute__(self,name):
  if name=='__format__':return lambda code:'ff'
  return super().__getattribute__(name)
 def __format__(self,code):return super().__format__(code)
class CustomInt(int):
 def __format__(self,code):return '2'
class OddString(str):
 def __str__(self):return 'WRONG'
class NastyInt(int):
 def __format__(self,code):raise RuntimeError('formatter failed')
def wire(v):return json.dumps(v,ensure_ascii=True)
cases=[]
for token in ['abc','a b','"\\\n\x00','Հայերեն😀','surrogate-\ud800',OddString('actual')]:
 for generation in [1,2**100,OddInt(1),CustomInt(1),True,0,-1,NastyInt(1)]:
  for mode in ['valid','foreign_token','foreign_generation','expired','invalid_deadline']:
   q=[]
   for engine in ['old','new']:
    core=native.DeadlineCore();actual=2 if isinstance(generation,CustomInt) else 1 if generation in [0,-1] or isinstance(generation,NastyInt) else int(generation)
    core.put('k','"scope"','1',format(actual,'x'),10,10,wire(token),20)
    used='other' if mode=='foreign_token' else token
    rev=actual+1 if mode=='foreign_generation' else generation
    now=20 if mode=='expired' else 10
    deadline=float('nan') if mode=='invalid_deadline' else 30
    try:
     if engine=='old':core.release('k',wire(used),format(rev,'x'),now,deadline)
     else:core.release_values('k',used,rev,now,deadline)
     result=['ok',core.get('k'),core.sequence]
    except Exception as e:result=['error',type(e).__name__,core.get('k'),core.sequence]
    q.append(result)
   cases.append({'token':repr(token),'generation':repr(generation),'generation_type':type(generation).__name__,'mode':mode,'same':q[0]==q[1],'results':q})
metadata={'python':sys.executable,'extension':native.__file__,'extension_sha256':hashlib.sha256(pathlib.Path(native.__file__).read_bytes()).hexdigest(),'direct_url':json.loads(importlib.metadata.distribution('aiogram-idle-native').read_text('direct_url.json'))}
p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(metadata['direct_url']['url']).path));metadata['wheel_path']=str(p);metadata['wheel_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(p) as z:
 name=next(n for n in z.namelist() if n.endswith('.so'));assert hashlib.sha256(z.read(name)).hexdigest()==metadata['extension_sha256']
json.dump({'metadata':metadata,'cases':cases},sys.stdout,ensure_ascii=True)
